import React from 'react';

const SurveyStep1 = () => {
    return (
        <div>
            
        </div>
    );
};

export default SurveyStep1;