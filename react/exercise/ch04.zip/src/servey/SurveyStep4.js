import React from 'react';

const SurveyStep4 = () => {
    return (
        <div>
            
        </div>
    );
};

export default SurveyStep4;