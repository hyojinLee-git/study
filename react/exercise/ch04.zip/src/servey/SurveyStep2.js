import React from 'react';

const SurveyStep2 = () => {
    return (
        <div>
            
        </div>
    );
};

export default SurveyStep2;