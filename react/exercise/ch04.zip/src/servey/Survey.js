import React from 'react';

const Survey = () => {
    return (
        <div>
            
        </div>
    );
};

export default Survey;