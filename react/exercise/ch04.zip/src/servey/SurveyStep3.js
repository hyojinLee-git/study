import React from 'react';

const SurveyStep3 = () => {
    return (
        <div>
            
        </div>
    );
};

export default SurveyStep3;