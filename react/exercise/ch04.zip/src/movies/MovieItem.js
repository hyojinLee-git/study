import React from 'react';

const MovieItem = () => {
    return (
        <div>
            
        </div>
    );
};

export default MovieItem;