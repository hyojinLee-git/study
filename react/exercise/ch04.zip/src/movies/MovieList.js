import React from 'react';

const MovieList = () => {
    return (
        <div>
            
        </div>
    );
};

export default MovieList;