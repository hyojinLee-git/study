import React from 'react';

const FriendList = () => {
    return (
        <div>
            
        </div>
    );
};

export default FriendList;