import React from 'react';

const Friend = () => {
    return (
        <div>
            
        </div>
    );
};

export default Friend;