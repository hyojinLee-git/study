import React from 'react';

const FriendItem = () => {
    return (
        <div>
            
        </div>
    );
};

export default FriendItem;