import React from 'react';
import Test1 from './components/Test1'

const App = () => {
  return (
    <div>
      <Test1 />
    </div>
  );
};

export default App;