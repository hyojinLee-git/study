import React, { useState } from 'react';
import axios from 'axios'

const Test1 = () => {
    const [data, setData] = useState([])

    return (
        <div>
            <h2> 데이터 불러오기 </h2>
            {
                data.map( item => <p key={item.id}>
                    {item.id} / {item.title}
                </p>)
            }
        </div>
    );
};

export default Test1;