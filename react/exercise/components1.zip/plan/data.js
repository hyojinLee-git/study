export default [
    {
        id:1 ,
        text:'업체미팅',
        day: '2021.04.30 pm 03:00',
        done : true 
    },
    {
        id:2 ,
        text:'전체 회의',
        day: '2021.05.03 am 09:00',
        done : true 
    },
    {
        id:3 ,
        text:'친구 모임',
        day: '2021.05.04 pm 07:00',
        done : false 
    },
]