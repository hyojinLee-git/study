import React from 'react';

const PlanItem = () => {
    return (
        <div>
            
        </div>
    );
};

export default PlanItem;