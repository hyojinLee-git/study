import React from 'react';

const Plan = () => {
    return (
        <div>
            
        </div>
    );
};

export default Plan;