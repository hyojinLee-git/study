import React from 'react';

const PlanList = () => {
    return (
        <div>
            
        </div>
    );
};

export default PlanList;