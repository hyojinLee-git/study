import React from 'react';
import Movies from './movies/Movies';

const App = () => {
  return (
    <div>
      <Movies />
    </div>
  );
};

export default App;